<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>add</title>
</head>
<body>

 <!-- validation -->
    <!-- variables -->
    <?php
    
    $name = $address = $salary =  "";
    //error
    $nameErr = $addressErr = $salaryErr ="";

    // name
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (empty($_POST["name"])) {
            $nameErr = "Please Enter Name";
        } else {
            $name = $_POST["name"];
        }

        // address
        if (!empty($_POST["address"])) {
            $address = sanitize($_POST["address"]);
        } else {
            $addressErr = "Please Enter a Valid address";
        }
        // salary
        if (!empty($_POST["salary"])) {
            $salary = sanitize($_POST["salary"]);
        } else {
            $salaryErr = "Please Enter salary";
        }

    }

    // sanitizing function
    function sanitize($value)
    {
        $value = trim($value);
        $value = stripslashes($value);
        $value = htmlspecialchars($value);
        return $value;
    }


    // db
    include "./db.php";
    $nameDB=$_REQUEST["name"];
    $addressDB=$_REQUEST["address"];
    $salaryDB = $_REQUEST["salary"];

    $sql="INSERT INTO employee (name,address,salary)
    VALUES('$nameDB','$addressDB','$salaryDB') ";

//to run query if it is not empty
if(!empty($nameDB) && !empty($addressDB) && !empty($salaryDB)  ){
    if($connection -> query($sql)== true){
        echo "<br>New Record added successfully" ;  
        $nameDB=$addressDB=$salaryDB=""; //to prevent duplicates

    }
    else{
        echo "Error: " .$sql. "<br>" . $connection -> error;
    }
}

    ?>



<!-- html form -->
    <div class="container my-5">

    <h1 class="mb-3">Add Records</h1><span class="text-danger ">* are required fields</span>
    <div>
        
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="post">

            <!-- name -->
            <div class="mb-3">
                <label class="form-label" for="name">Name</label>
                <span class="text-danger"><sup>*</sup><?php echo $nameErr ?> </span>
                <input class="form-control" type="text" name="name" id="name" >
                
            </div>
            <div class="mb-3">
                <!-- E-mail -->
                <label class="form-label" for="address">Address</label>
                <span class="text-danger"><sup>*</sup><?php echo $addressErr ?> </span>
                <input class="form-control" type="text" id="address" name="address" >
                
            </div>
            <div class="mb-3">
                <!-- url -->
                <label class="form-label" for="salary">salary</label>
                <span class="text-danger"><sup>*</sup><?php echo $salaryErr ?> </span>
                <input class="form-control" type="text" name="salary" >
                
                </div>
            
    <!-- submit -->
    <input class="btn btn-success" type="submit">




    </form>
    <a href="../index.php">Back to Employee List</a>
        
    <!-- input details -->
    <h3>Your Input Details:</h3>
    <p class='inputHeading'><span><?php ($name != "" ) && (print "Name: ". $name); ?></span></p>
    <p class='inputHeading'><span><?php ($address != "" )&& (print "address: ". $address); ?></span></p>
    <p class='inputHeading'><span><?php ($salary != "" )&& (print "salary: ". $salary); ?></span></p>
    
    </div>
    </div>
    
</body>
</html>