<?php
include "db.php";

if (isset($_GET["id"])) {
    // Delete employee
    $id = $_GET["id"];
    $sql = "DELETE FROM employee WHERE id='$id'";
    if ($connection->query($sql) === TRUE) {
        echo "Employee deleted successfully";
    } else {
        echo "Error deleting employee: " . $connection->error;
    }
} else {
    echo "Invalid request";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Employee</title>
</head>
<body>
    <h1>Deleted Employee id: <?php echo $id ?></h1>
    <a href="../index.php">Back to Employee List</a>
</body>
</html>